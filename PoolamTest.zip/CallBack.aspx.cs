﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Poolam;

namespace PoolamTest
{
    public partial class CallBack : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["invoiceKey"] != null)
            {
                string apiKey = "06f93738564786c0be63f810fbafcd74";
                string invoiceKey = Session["invoiceKey"].ToString();
                string amount = Session["Amount"].ToString();
                PoolamPay pay = new PoolamPay();

                var result = pay.CheckPayment(apiKey, invoiceKey);

                if (result.status == 1)
                {
                    lblAmoun.Text = result.amount.ToString();
                    lblBackCod.Text = result.bank_code.ToString();
                    lblBankCode.Visible = true;
                    lblBackCod.Visible = true;
                }
                else
                {
                    lblAmoun.Text = amount;
                    lblerrCode.Text = result.errorCode.ToString();
                    lblerrDescription.Text = result.errorDescription.ToString();
                    lblerrorCode.Visible = true;
                    lblerrorDescription.Visible = true;
                    lblerrCode.Visible = true;
                    lblerrDescription.Visible = true;
                }

            }
            else
            {
                Response.Redirect("Default.aspx");
            }
        }
    }
}