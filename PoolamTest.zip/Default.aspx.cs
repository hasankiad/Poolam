﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Poolam;

namespace PoolamTest
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnPay_Click(object sender, EventArgs e)
        {
            string apiKey = "06f93738564786c0be63f810fbafcd74";
            int amount = 0;
            string returnURL = "http://localhost:58728/CallBack.aspx";
            try
            {
                amount = int.Parse(txtAmount.Text);

                PoolamPay pay = new PoolamPay();
                var result = pay.StartPayment(apiKey, amount, returnURL);

                if (result.status == 1)
                {
                    string invoiceKey = result.invoice_key;
                    Session["invoiceKey"] = invoiceKey;
                    Session["Amount"] = amount;
                    Response.Redirect("https://poolam.ir/invoice/pay/" + invoiceKey);
                }
                else
                {
                    lblerrCode.Text = result.errorCode.ToString();
                    lblerrDescription.Text = result.errorDescription.ToString();
                    lblerrorCode.Visible = true;
                    lblerrorDescription.Visible = true;
                    lblerrCode.Visible = true;
                    lblerrDescription.Visible = true;
                }
            }
            catch
            {
                if (amount <= 0 || amount < 1000)
                {
                    lblError.Text = "The amount should be at least 1000 Rials.";
                    lblMError.Visible = true;
                    lblError.Visible = true;
                }
            }
        }
    }
}